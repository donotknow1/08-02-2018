package com.air.client;

import java.io.ObjectInputStream.GetField;
import java.util.Scanner;

import com.air.bean.AirBean;
import com.air.service.AirServiceImpl;
import com.air.service.IAirService;

public class AirClient 
{
	
	public static void main(String[] args)
	{
		System.out.println("*****************Flight Booking***************");
		System.out.println("1.Enter Details for Booking Flight");
		System.out.println("2.Track the Deatils");
		System.out.println("3.Exit");
		
		
		IAirService val=new AirServiceImpl();
		Scanner scan=new Scanner(System.in);
		int option=scan.nextInt();
		
		switch (option) {
		case 1:
			System.out.println("you choosen option to book flight");
			int flightid;
			do {
				System.out.println("Enter flight id");
				flightid=scan.nextInt();	
			}while(val.validateflightid(flightid)==false);
			 
			String cuName;
			do {
				System.out.println("Enter the Name");
				cuName=scan.next();	
			}while(val.validatecustomerName(cuName)==false);
			
			String mobileNo;
			do {
				System.out.println("Enter the MobileNo");
				mobileNo=scan.next();	
			}while(val.validatecustomermobileno(mobileNo)==false);
			
			String email;
			do {
				System.out.println("Enter the EmailId");
				email=scan.next();	
			}while(val.validatecustomeremail(email)==false);
			
		
			boolean b=insertCustomerDetails();
		
			if(b==true)
			{
				System.out.println("Details Entered");
				System.out.println("TicketId :");   //to  didplay auto generated ticketid
				System.out.println("Name     :"+cuName);
				System.out.println("MobileNo :"+mobileNo);
				System.out.println("EmailId  :"+email);
				
			}
			else
			{
				System.err.println("No Details Entered");
			}
			
			
			break;

		default:
			break;
		}
		
		
	}

	private static boolean insertCustomerDetails() {
		IAirService in=new AirServiceImpl();
		in.insertToDb();
		return in.insertToDb();
	}

}
