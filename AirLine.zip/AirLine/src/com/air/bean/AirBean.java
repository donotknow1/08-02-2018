package com.air.bean;

public class AirBean {
	
	//flight details
	private int flightId;
	private String flightName;
	private String flightDeparture;
	private String flightArrival;
	private String flightTime;
	private String flightSeats;
	private int ticketId;
	
	//user to book flight
	private String customerName;
	private String MobileNo;
	private String emailId;
	public int getFlightId() {
		return flightId;
	}
	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public String getFlightDeparture() {
		return flightDeparture;
	}
	public void setFlightDeparture(String flightDeparture) {
		this.flightDeparture = flightDeparture;
	}
	public String getFlightArrival() {
		return flightArrival;
	}
	public void setFlightArrival(String flightArrival) {
		this.flightArrival = flightArrival;
	}
	public String getFlightTime() {
		return flightTime;
	}
	public void setFlightTime(String flightTime) {
		this.flightTime = flightTime;
	}
	public String getFlightSeats() {
		return flightSeats;
	}
	public void setFlightSeats(String flightSeats) {
		this.flightSeats = flightSeats;
	}
	public int getTicketId() {
		return ticketId;
	}
	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getMobileNo() {
		return MobileNo;
	}
	public void setMobileNo(String mobileNo) {
		MobileNo = mobileNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	//Constructors
	public AirBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	//constructor using all fields
	public AirBean(int flightId, String flightName, String flightDeparture, String flightArrival, String flightTime,
			String flightSeats, int ticketId, String customerName, String mobileNo, String emailId) {
		super();
		this.flightId = flightId;
		this.flightName = flightName;
		this.flightDeparture = flightDeparture;
		this.flightArrival = flightArrival;
		this.flightTime = flightTime;
		this.flightSeats = flightSeats;
		this.ticketId = ticketId;
		this.customerName = customerName;
		MobileNo = mobileNo;
		this.emailId = emailId;
	}
	//constructor without ticketId
	public AirBean(int flightId, String flightName, String flightDeparture, String flightArrival, String flightTime,
			String flightSeats, String customerName, String mobileNo, String emailId) {
		super();
		this.flightId = flightId;
		this.flightName = flightName;
		this.flightDeparture = flightDeparture;
		this.flightArrival = flightArrival;
		this.flightTime = flightTime;
		this.flightSeats = flightSeats;
		this.customerName = customerName;
		MobileNo = mobileNo;
		this.emailId = emailId;
	}
	
	//to string
	@Override
	public String toString() {
		return "AirBean [flightId=" + flightId + ", flightName=" + flightName + ", flightDeparture=" + flightDeparture
				+ ", flightArrival=" + flightArrival + ", flightTime=" + flightTime + ", flightSeats=" + flightSeats
				+ ", ticketId=" + ticketId + ", customerName=" + customerName + ", MobileNo=" + MobileNo + ", emailId="
				+ emailId + "]";
	}
	
	
	
	
	
	
	

}
