package com.air.dao;

public class AirDaoImpl implements IAirDao {

	@Override
	public void insertion() {
		
		
	}

}
