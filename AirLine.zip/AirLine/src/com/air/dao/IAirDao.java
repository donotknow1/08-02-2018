package com.air.dao;

public interface IAirDao {

	void insertion();

}
