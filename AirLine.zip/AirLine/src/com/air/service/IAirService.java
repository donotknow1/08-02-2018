package com.air.service;

public interface IAirService {

	boolean validateflightid(int flightid);

	boolean validatecustomeremail(String email);

	boolean validatecustomermobileno(String mobileNo);

	boolean validatecustomerName(String cuName);

	boolean insertToDb();

}
