package com.air.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.air.dao.AirDaoImpl;
import com.air.dao.IAirDao;

public class AirServiceImpl implements IAirService{

	@Override
	public boolean validateflightid(int flightid) {
		Pattern p=Pattern.compile("[1-9][0-9]{3}");
		String flight=Integer.toString(flightid);
		Matcher m=p.matcher(flight);
		
        if(m.matches())
        {
        	return true;
			
		      }
		else {
			System.err.println("Enetered flight id doesn't exist");
			return false;	
		}
	}

	@Override
	public boolean validatecustomeremail(String email) {
		Pattern p=Pattern.compile("[a-z]{3}");
		//Pattern p=Pattern.compile("[a-z0-9]{5}[@][(gmail.com)|(capgemini.com)|(yahoo.com)");
		Matcher m=p.matcher(email);
		
		if(m.matches()) 
		{
			return true;
			
		}
		else {
			System.err.println("Enter a valid email id");
			return false;	
		}
		
	}

	@Override
	public boolean validatecustomermobileno(String mobileNo) {
		
		Pattern p=Pattern.compile("[6-9][0-9]{9}");
		Matcher m=p.matcher(mobileNo);
       if(m.matches()) {
    	   return true;
			
		     }
		else {
			System.err.println("Enter a valid Mobileno");
			return false;	
		}
	}

	@Override
	public boolean validatecustomerName(String cuName) {
		Pattern p=Pattern.compile("[A-Za-z]{5,15}");
		Matcher m=p.matcher(cuName);
		
      if(m.matches()) {
    	  return true;
			
		}
		else {
			System.err.println("Enter a valid CustomerName");
			return false;	
		}
	}

	@Override
	public boolean insertToDb() {
		IAirDao dao=new AirDaoImpl();
		dao.insertion();
		return true;
	}

	
}
